package fsd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author js5388
 */
public class pr2 extends javax.swing.JFrame {
     String a;
  String b="",c;
  String ytu="0";
  String yn="1";
  String jLb1="jLabel1";
  String jLb2="jLabel2";
  String jLb3="jLabel3";
  String jLb4="jLabel4";
  String jLb6="jLabel6";
  String jLb7="jLabel7";
  String jLb8="jLabel8";
  String jLb9="jLabel9";
  String jLb10="jLabel10";
  String jLb11="jLabel11";
   String jLb12="jLabel12";
   String jLb13="jLabel13";
   String jLb14="jLabel14";
   String jLb15="jLabel15";
   String jLb16="jLabel16";
   String jLb17="jLabel17";
   String jLb18="jLabel18";
   String jLb19="jLabel19";
   String jLb20="jLabel20";
String jLb25="jLabel25";
String jLb21="jLabel21";
String jLb22="jLabel22";
String jLb23="jLabel23";
String jLb24="jLabel24";
  String jLb36="jLabel36";
   String jLb37="jLabel37";
   String jLb38="jLabel38";
   String jLb39="jLabel39";
   String jLb40="jLabel40";
   String jLb41="jLabel41";
   String jLb42="jLabel42";
String jLb43="jLabel43";
String jLb46="jLabel46";
String jLb47="jLabel47";
String jLb48="jLabel48";
String jLb49="jLabel49";
   String booked;
   String booked1;
     String Moviename;
    String seatbooked="seat_booked";
    int cost =0;

    int jLB1=0;
    int jLB2=0;
    int jLB3=0;
    int jLB4=0;
    int jLB5=0;
    int jLB6=0;
    int jLB7=0;
    int jLB8=0;
    int jLB9=0;
    int jLB10=0;
    int jLB11=0;
    int jLB12=0;
    int jLB13=0;
    int jLB14=0;
    int jLB15=0;
    int jLB16=0;
    int jLB17=0;
    int jLB18=0;
    int jLB19=0;
    int jLB20=0;
    int jLB21=0;
    int jLB22=0;
    int jLB23=0;
    int jLB24=0;
    int jLB25=0;
    int jLB36=0;
    int jLB37=0;
    int jLB38=0;
    int jLB39=0;
    int jLB40=0;
    int jLB41=0;
    int jLB42=0;
    int jLB43=0;
    int jLB46=0;
    int jLB47=0;
    int jLB48=0;
    int jLB49=0;

    /**
     * Creates new form pr2
     */
    public pr2() {
        initComponents();
        this.setLocationRelativeTo(null);
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
             jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                  jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
           jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
               
                     jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                          jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                               jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                    jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                         jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                              jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                   jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                        jLabel13.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                             jLabel14.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                                  jLabel15.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                                       jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                                            jLabel17.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                                                 jLabel18.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                                                      jLabel19.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
     jLabel20.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
          jLabel21.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
               jLabel22.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                    jLabel23.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                         jLabel24.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                              jLabel25.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                   
     jLabel36.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
          jLabel37.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
               jLabel38.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                    jLabel39.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                         jLabel40.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                              jLabel41.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                   jLabel42.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                        jLabel43.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                            
                                                       jLabel46.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                            jLabel47.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                                 jLabel48.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                                      jLabel49.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
                                                                    
       
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel26 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jLabel26.setText("PLATINUM");

        jLabel28.setText("RS:-  350");

        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel1.setOpaque(true);
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel1MouseEntered(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(204, 204, 255));
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel2.setOpaque(true);
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(204, 204, 255));
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel3.setOpaque(true);
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel4.setBackground(new java.awt.Color(204, 204, 255));
        jLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel4.setOpaque(true);
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel9.setBackground(new java.awt.Color(204, 204, 255));
        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel9.setOpaque(true);
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        jLabel8.setBackground(new java.awt.Color(204, 204, 255));
        jLabel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel8.setOpaque(true);
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        jLabel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel7.setOpaque(true);
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel6.setBackground(new java.awt.Color(204, 204, 255));
        jLabel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel6.setOpaque(true);
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel13.setBackground(new java.awt.Color(204, 204, 255));
        jLabel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel13.setOpaque(true);
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });

        jLabel12.setBackground(new java.awt.Color(204, 204, 255));
        jLabel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel12.setOpaque(true);
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        jLabel11.setBackground(new java.awt.Color(204, 204, 255));
        jLabel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel11.setOpaque(true);
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });

        jLabel10.setBackground(new java.awt.Color(204, 204, 255));
        jLabel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel10.setOpaque(true);
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        jLabel20.setBackground(new java.awt.Color(204, 204, 255));
        jLabel20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel20.setOpaque(true);
        jLabel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel20MouseClicked(evt);
            }
        });

        jLabel21.setBackground(new java.awt.Color(204, 204, 255));
        jLabel21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel21.setOpaque(true);
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
        });

        jLabel22.setBackground(new java.awt.Color(204, 204, 255));
        jLabel22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel22.setOpaque(true);
        jLabel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel22MouseClicked(evt);
            }
        });

        jLabel25.setBackground(new java.awt.Color(204, 204, 255));
        jLabel25.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel25.setOpaque(true);
        jLabel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel25MouseClicked(evt);
            }
        });

        jLabel15.setBackground(new java.awt.Color(204, 204, 255));
        jLabel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel15.setOpaque(true);
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });

        jLabel17.setBackground(new java.awt.Color(204, 204, 255));
        jLabel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel17.setOpaque(true);
        jLabel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel17MouseClicked(evt);
            }
        });

        jLabel18.setBackground(new java.awt.Color(204, 204, 255));
        jLabel18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel18.setOpaque(true);
        jLabel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel18MouseClicked(evt);
            }
        });

        jLabel19.setBackground(new java.awt.Color(204, 204, 255));
        jLabel19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel19.setOpaque(true);
        jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel19MouseClicked(evt);
            }
        });

        jLabel23.setBackground(new java.awt.Color(204, 204, 255));
        jLabel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel23.setOpaque(true);
        jLabel23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel23MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel23MouseEntered(evt);
            }
        });

        jLabel24.setBackground(new java.awt.Color(204, 204, 255));
        jLabel24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel24.setOpaque(true);
        jLabel24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel24MouseClicked(evt);
            }
        });

        jLabel14.setBackground(new java.awt.Color(204, 204, 255));
        jLabel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel14.setOpaque(true);
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });

        jLabel16.setBackground(new java.awt.Color(204, 204, 255));
        jLabel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel16.setOpaque(true);
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });

        jLabel29.setText("RS:-  250");

        jLabel5.setText("GOLD");

        jLabel27.setText("SILVER");

        jLabel30.setText("RS:-  185");

        jLabel47.setBackground(new java.awt.Color(204, 204, 255));
        jLabel47.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel47.setOpaque(true);
        jLabel47.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel47MouseClicked(evt);
            }
        });

        jLabel46.setBackground(new java.awt.Color(204, 204, 255));
        jLabel46.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel46.setOpaque(true);
        jLabel46.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel46MouseClicked(evt);
            }
        });

        jLabel49.setBackground(new java.awt.Color(204, 204, 255));
        jLabel49.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel49.setOpaque(true);
        jLabel49.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel49MouseClicked(evt);
            }
        });

        jLabel48.setBackground(new java.awt.Color(204, 204, 255));
        jLabel48.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel48.setOpaque(true);
        jLabel48.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel48MouseClicked(evt);
            }
        });

        jLabel39.setBackground(new java.awt.Color(204, 204, 255));
        jLabel39.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel39.setOpaque(true);
        jLabel39.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel39MouseClicked(evt);
            }
        });

        jLabel38.setBackground(new java.awt.Color(204, 204, 255));
        jLabel38.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel38.setOpaque(true);
        jLabel38.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel38MouseClicked(evt);
            }
        });

        jLabel37.setBackground(new java.awt.Color(204, 204, 255));
        jLabel37.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel37.setOpaque(true);
        jLabel37.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel37MouseClicked(evt);
            }
        });

        jLabel36.setBackground(new java.awt.Color(204, 204, 255));
        jLabel36.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel36.setOpaque(true);
        jLabel36.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel36MouseClicked(evt);
            }
        });

        jLabel43.setBackground(new java.awt.Color(204, 204, 255));
        jLabel43.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel43.setOpaque(true);
        jLabel43.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel43MouseClicked(evt);
            }
        });

        jLabel42.setBackground(new java.awt.Color(204, 204, 255));
        jLabel42.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel42.setOpaque(true);
        jLabel42.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel42MouseClicked(evt);
            }
        });

        jLabel41.setBackground(new java.awt.Color(204, 204, 255));
        jLabel41.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel41.setOpaque(true);
        jLabel41.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel41MouseClicked(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3), "Seat Selection", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Tahoma", 1, 18))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 664, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 425, Short.MAX_VALUE)
        );

        jLabel40.setBackground(new java.awt.Color(204, 204, 255));
        jLabel40.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel40.setOpaque(true);
        jLabel40.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel40MouseClicked(evt);
            }
        });

        jButton1.setText("next");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 699, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(44, 44, 44)
                            .addComponent(jLabel29))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(280, 280, 280)
                            .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(525, 525, 525)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(493, 493, 493)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(312, 312, 312)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(208, 208, 208)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(343, 343, 343)
                            .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(44, 44, 44)
                            .addComponent(jLabel27))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(461, 461, 461)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(493, 493, 493)
                            .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(525, 525, 525)
                            .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(312, 312, 312)
                            .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(144, 144, 144)
                            .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(112, 112, 112)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(344, 344, 344)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(208, 208, 208)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(176, 176, 176)
                            .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(375, 375, 375)
                            .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(176, 176, 176)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(376, 376, 376)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(376, 376, 376)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(280, 280, 280)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 679, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(461, 461, 461)
                            .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(49, 49, 49)
                            .addComponent(jLabel30))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(525, 525, 525)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(557, 557, 557)
                            .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(44, 44, 44)
                            .addComponent(jLabel28))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(112, 112, 112)
                            .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(312, 312, 312)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(144, 144, 144)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(493, 493, 493)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(176, 176, 176)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(557, 557, 557)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(600, 600, 600)
                            .addComponent(jButton1))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(44, 44, 44)
                            .addComponent(jLabel26))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(557, 557, 557)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(144, 144, 144)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(461, 461, 461)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(112, 112, 112)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(208, 208, 208)
                            .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(344, 344, 344)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 679, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(44, 44, 44)
                            .addComponent(jLabel5))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(280, 280, 280)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 483, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(196, 196, 196)
                            .addComponent(jLabel29))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(313, 313, 313)
                            .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(193, 193, 193)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(196, 196, 196)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(313, 313, 313)
                            .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(289, 289, 289)
                            .addComponent(jLabel27))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(193, 193, 193)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(310, 310, 310)
                            .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(310, 310, 310)
                            .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(313, 313, 313)
                            .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(313, 313, 313)
                            .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(313, 313, 313)
                            .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(313, 313, 313)
                            .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(196, 196, 196)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(196, 196, 196)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(133, 133, 133)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(310, 310, 310)
                            .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(313, 313, 313)
                            .addComponent(jLabel30))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(310, 310, 310)
                            .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(101, 101, 101)
                            .addComponent(jLabel28))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(313, 313, 313)
                            .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(196, 196, 196)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(196, 196, 196)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(193, 193, 193)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(193, 193, 193)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(424, 424, 424)
                            .addComponent(jButton1))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(61, 61, 61)
                            .addComponent(jLabel26))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(89, 89, 89)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(196, 196, 196)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(313, 313, 313)
                            .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(196, 196, 196)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(371, 371, 371)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(163, 163, 163)
                            .addComponent(jLabel5))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(196, 196, 196)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked

        if(jLB1==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB1++;
        if((jLB1==0)||(jLB1==2)||(jLB1==4)||(jLB1==6)||(jLB1==8)||(jLB1==10)||(jLB1==12))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb1+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB1%2==1)||(jLB1==3)||(jLB1==5)||(jLB1==7)||(jLB1==9)||(jLB1==11)||(jLB1==13))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb1+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1MouseEntered

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        if(jLB2==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB2++;
        if((jLB2==0)||(jLB2==2)||(jLB2==4)||(jLB2==6)||(jLB2==8)||(jLB2==10)||(jLB2==12))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb2+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB2==1)||(jLB2==3)||(jLB2==5)||(jLB2==7)||(jLB2==9)||(jLB2==11)||(jLB2==13))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb2+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked

        if(jLB3==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB3++;
        if((jLB3%2==0)&&(jLB3<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb3+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB3%2==1)&&(jLB3<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb3+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked

        if(jLB4==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB4++;
        if((jLB4%2==0)&&(jLB4<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb4+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB4%2==1)&&(jLB4<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb4+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        if(jLB9==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB9++;
        if((jLB9%2==0)&&(jLB9<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb9+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB9%2==1)&&(jLB9<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb9+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        if(jLB8==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB8++;
        if((jLB8%2==0)&&(jLB8<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb8+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB8%2==1)&&(jLB8<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb8+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        if(jLB7==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB7++;
        if((jLB7%2==0)&&(jLB7<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb7+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB7%2==1)&&(jLB7<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb7+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        if(jLB6==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB6++;
        if((jLB6%2==0)&&(jLB6<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb6+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB6%2==1)&&(jLB6<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb6+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseClicked

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        if(jLB13==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB13++;
        if((jLB13%2==0)&&(jLB13<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb13+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel13.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB13%2==1)&&(jLB13<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb13+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel13.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel13MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        if(jLB12==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB12++;
        if((jLB12%2==0)&&(jLB12<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb12+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB12%2==1)&&(jLB12<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb12+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        if(jLB11==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB11++;
        if((jLB11%2==0)&&(jLB11<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb11+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB11%2==1)&&(jLB11<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb11+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        if(jLB10==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB10++;
        if((jLB10%2==0)&&(jLB10<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb10+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\ha3434\\Desktop\\nnjk\\src\\fsd\\brown.png"));
            cost= cost +350;
        }
        if((jLB10%2==1)&&(jLB10<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb10+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel10MouseClicked

    private void jLabel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel20MouseClicked
       if(jLB20==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB20++;
        if((jLB20%2==0)&&(jLB20<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb20+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel20.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB20%2==1)&&(jLB20<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb20+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel20.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel20MouseClicked

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
        if(jLB21==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB21++;
        if((jLB21%2==0)&&(jLB21<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb21+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel21.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB21%2==1)&&(jLB21<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb21+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel21.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel21MouseClicked

    private void jLabel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel22MouseClicked
       if(jLB22==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB22++;
        if((jLB22%2==0)&&(jLB22<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb22+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel22.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB22%2==1)&&(jLB22<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb22+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel22.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel22MouseClicked

    private void jLabel25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel25MouseClicked
       if(jLB25==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB25++;
        if((jLB25%2==0)&&(jLB25<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb25+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel25.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB25%2==1)&&(jLB25<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb25+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel25.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel25MouseClicked

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked
        if(jLB15==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB15++;
        if((jLB15%2==0)&&(jLB15<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb15+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel15.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB15%2==1)&&(jLB15<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb15+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel15.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel15MouseClicked

    private void jLabel17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel17MouseClicked
        if(jLB17==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB17++;
        if((jLB17%2==0)&&(jLB17<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb17+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel17.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB17%2==1)&&(jLB17<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb17+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel17.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel17MouseClicked

    private void jLabel18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel18MouseClicked
        if(jLB18==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB18++;
        if((jLB18%2==0)&&(jLB18<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb18+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel18.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB18%2==1)&&(jLB18<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb18+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel18.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel18MouseClicked

    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
        if(jLB19==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB19++;
        if((jLB19%2==0)&&(jLB19<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb19+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel19.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB19%2==1)&&(jLB19<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb19+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel19.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel19MouseClicked

    private void jLabel23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel23MouseClicked
        if(jLB23==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB23++;
        if((jLB23%2==0)&&(jLB23<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb23+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel23.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB23%2==1)&&(jLB23<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb23+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel23.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel23MouseClicked

    private void jLabel23MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel23MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel23MouseEntered

    private void jLabel24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel24MouseClicked

      if(jLB24==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB24++;
        if((jLB24%2==0)&&(jLB24<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb24+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel24.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB24%2==1)&&(jLB24<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb24+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel24.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel24MouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        if(jLB14==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB14++;
        if((jLB14%2==0)&&(jLB14<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb14+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel14.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB14%2==1)&&(jLB14<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb14+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel14.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel14MouseClicked

    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked

        if(jLB16==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB16++;
        if((jLB16%2==0)&&(jLB16<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb16+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB16%2==1)&&(jLB16<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb16+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel16MouseClicked

    private void jLabel47MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel47MouseClicked
        if(jLB47==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB47++;
        if((jLB47%2==0)&&(jLB47<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb47+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel47.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB47%2==1)&&(jLB47<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb47+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel47.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel47MouseClicked

    private void jLabel46MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel46MouseClicked
       if(jLB46==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB46++;
        if((jLB46%2==0)&&(jLB46<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb46+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel46.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB46%2==1)&&(jLB46<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb46+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel46.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel46MouseClicked

    private void jLabel49MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel49MouseClicked
       if(jLB49==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB49++;
        if((jLB49%2==0)&&(jLB49<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb49+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel49.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB49%2==1)&&(jLB49<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb49+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel49.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel49MouseClicked

    private void jLabel48MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel48MouseClicked
        if(jLB48==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB48++;
        if((jLB48%2==0)&&(jLB48<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb48+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel48.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB48%2==1)&&(jLB48<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb48+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel48.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel48MouseClicked

    private void jLabel39MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel39MouseClicked
       if(jLB39==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB39++;
        if((jLB39%2==0)&&(jLB39<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb39+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel39.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB39%2==1)&&(jLB39<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb39+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel39.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel39MouseClicked

    private void jLabel38MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel38MouseClicked
       if(jLB38==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB38++;
        if((jLB38%2==0)&&(jLB38<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb38+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel38.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB38%2==1)&&(jLB38<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb38+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel38.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel38MouseClicked

    private void jLabel37MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel37MouseClicked
       if(jLB37==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB37++;
        if((jLB37%2==0)&&(jLB37<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb37+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel37.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB37%2==1)&&(jLB37<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb37+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel37.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel37MouseClicked

    private void jLabel36MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel36MouseClicked
        if(jLB36==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB36++;
        if((jLB36%2==0)&&(jLB36<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb36+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel36.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB36%2==1)&&(jLB36<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb36+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel36.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel36MouseClicked

    private void jLabel43MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel43MouseClicked
        if(jLB43==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB43++;
        if((jLB43%2==0)&&(jLB43<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb43+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel43.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB43%2==1)&&(jLB43<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb43+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel43.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel43MouseClicked

    private void jLabel42MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel42MouseClicked
        if(jLB42==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB42++;
        if((jLB42%2==0)&&(jLB42<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb42+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel42.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB42%2==1)&&(jLB42<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb42+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel42.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel42MouseClicked

    private void jLabel41MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel41MouseClicked
       if(jLB41==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB41++;
        if((jLB41%2==0)&&(jLB41<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb41+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel41.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB41%2==1)&&(jLB41<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb41+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel41.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel41MouseClicked

    private void jLabel40MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel40MouseClicked
       if(jLB40==0)
        {
            a=",p1";
            b="" +a;
        }

        jLB40++;
        if((jLB40%2==0)&&(jLB40<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+ytu+"' where label ='"+jLb40+"';";

                stmt.executeUpdate(query);

            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel40.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\brown.PNG"));
            cost= cost +350;
        }
        if((jLB40%2==1)&&(jLB40<50))
        {
            try

            {

                Class.forName("java.sql.DriverManager");
                Connection con= (Connection)
                DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
                Statement stmt= (Statement) con.createStatement();
                String query ="update "+Moviename+" set "+booked+" ='"+yn+"' where label ='"+jLb40+"';";

                stmt.executeUpdate(query);
            }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
            jLabel40.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
            cost= cost -350;
        }

       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel40MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        System.out.println(cost);
        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)
            DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
            Statement stmt = (Statement) con.createStatement();

            String query="Create table if not exists cost(S_no int not null primary key auto_increment,cost integer(5)) ;";

            stmt.executeUpdate(query);

        }

        catch (Exception e)
        {
            JOptionPane.showMessageDialog (this, e.getMessage());
        }

        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)
            DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
            Statement stmt = (Statement) con.createStatement();

            String query="insert into cost(cost) values('"+cost+"');";

            stmt.executeUpdate(query);

        }

        catch (Exception e)
        {
            JOptionPane.showMessageDialog (this, e.getMessage());
        }
        dispose();
        new payment().setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
try
   
 {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select date from date e where S_no in( select max(S_no) from date ); ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked=rs.getString("date");
  
        }}
         catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }

try
   
 {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select moviename from moviename e where S_no in( select max(S_no) from moviename ); ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     Moviename=rs.getString("moviename");
     
     System.out.print(Moviename);
  
        }}
         catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }



        
        try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb1+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
 booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
         jLB1=jLB1 + 1000;

     }
         }
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        } 
        
            try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb2+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
          jLB2=jLB2 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb3+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB3=jLB3 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                System.out.println(booked);
                
                    try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb4+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB4=jLB4 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                        try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb6+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG"));
           jLB6=jLB6 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                            try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb7+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB7=jLB7 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb8+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB8=jLB8 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                    try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb9+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB9=jLB9 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                        try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb10+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB10=jLB10 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                        try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb11+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB11=jLB11 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                        
                                                                         try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb12+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB12=jLB12 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                          try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb13+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel13.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB13=jLB13 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                           try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb14+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel14.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB14=jLB14 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                            try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb15+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel15.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB15=jLB15 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                             try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb16+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB16=jLB16 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                              try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb17+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel17.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB17=jLB17 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                               try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb18+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel18.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB18=jLB18 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                                try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb19+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel19.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB19=jLB19 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                                 try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb20+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel20.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB20=jLB20 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                                  try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb21+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel21.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB21=jLB21 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                                   try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb22+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel22.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB22=jLB22 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                                    try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb23+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel23.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB23=jLB23 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                                     try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb24+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel24.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB24=jLB24 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                                                                                      try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb25+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel25.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB25=jLB25 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        } try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb36+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel36.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB36=jLB36 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        } try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb37+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel37.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB37=jLB37 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        } try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb38+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel38.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB38=jLB38 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        } try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb39+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel39.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB39=jLB39 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        } try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb40+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel40.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB40=jLB40 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
         try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb41+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel41.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB41=jLB41 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        } try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb42+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel42.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB42=jLB42 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
       
                 try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb43+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel43.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB43=jLB43 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                  try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb46+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel46.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB46=jLB46 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                   try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb47+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel47.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB47=jLB47 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                    try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb48+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel48.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB48=jLB48 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }
                     try
        {
         Class.forName("java.sql.DriverManager");
         Connection con= (Connection)
                 DriverManager.getConnection
                 ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
         Statement stmt= (Statement) con.createStatement();
         String query ="select "+booked+" from "+Moviename+" where label ='"+jLb49+"'; ";
     
    
         
         ResultSet rs=stmt.executeQuery(query); 
         while(rs.next())
         {
         
     booked1=rs.getString(booked);
     if("1".equals(booked1))
     
     {
         jLabel49.setIcon(new javax.swing.ImageIcon("C:\\Users\\js5388\\Documents\\NetBeansProjects\\getmyseat1\\pics\\red.PNG")); 
           jLB49=jLB49 + 1000;
     }}
        
        
        } catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e.getMessage());
        }           // TODO add your handling code here:
    }//GEN-LAST:event_formWindowOpened

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pr2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pr2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pr2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pr2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pr2().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator3;
    // End of variables declaration//GEN-END:variables
}
