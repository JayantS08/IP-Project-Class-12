package fsd;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author js5388
 */
public class login1 extends javax.swing.JFrame {

    /**
     * Creates new form login1
     */
    public login1() {
        initComponents();
        this.setLocationRelativeTo(null);
        try     
   {
                Class.forName("java.sql.DriverManager");
                Connection con = (Connection)
                DriverManager.getConnection("jdbc:mysql://localhost:3306/mySql", "root","1234");
                java.sql.Statement stmt = (java.sql.Statement) con.createStatement();
               
String query="Create Database if not exists have_my_seat;";
System.out.println("Database Successfully created");
  stmt.executeUpdate(query);
            }
            
            catch (Exception e)
            {
                JOptionPane.showMessageDialog (this, e.getMessage());
            }
         try
            {
                Class.forName("java.sql.DriverManager");
                Connection con = (Connection)
                DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
                java.sql.Statement stmt = (java.sql.Statement) con.createStatement();
               
String query="Create table if not exists Admin(Enrollno int Not Null primary key auto_increment ,Name Varchar(25) Not Null,Rel date not null,Director varchar(60),Actor varchar(20) not null, Show_date date not null, Ad varchar(256), Summary varchar(256)) ;";

System.out.println("Table Successfully created");
  stmt.executeUpdate(query);
  
            }
            
            catch (Exception e)
            {
                JOptionPane.showMessageDialog (this, e.getMessage());
            }
         try
            {
                Class.forName("java.sql.DriverManager");
                Connection con = (Connection)
                DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
                java.sql.Statement stmt = (java.sql.Statement) con.createStatement();
               
String query="Create table if not exists rating(S_no int Not Null primary key auto_increment ,movie Varchar(25), rating_sum integer(20),rating_no integer(5)); ;";

System.out.println("Table Successfully created");
  stmt.executeUpdate(query);
  
            }
            
            catch (Exception e)
            {
                JOptionPane.showMessageDialog (this, e.getMessage());
            }
        
        setLocationRelativeTo(null);
         try
            {
                Class.forName("java.sql.DriverManager");
                Connection con = (Connection)
                DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
                Statement stmt = (Statement) con.createStatement();
               
String query="Create table if not exists cost(S_no int not null primary key auto_increment,cost integer(5)) ;";


  stmt.executeUpdate(query);
  
            }
            
            catch (Exception e)
            {
                JOptionPane.showMessageDialog (this, e.getMessage());
            }
      try
            {
                Class.forName("java.sql.DriverManager");
                Connection con = (Connection)
                DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
                Statement stmt = (Statement) con.createStatement();
               
String query="Create table if not exists movie(S_no int not null primary key auto_increment,name varchar(20)) ;";


  stmt.executeUpdate(query);
  
            }
            
            catch (Exception e)
            {
                JOptionPane.showMessageDialog (this, e.getMessage());
            }
        
        setLocationRelativeTo(null);
        try
            {
                Class.forName("java.sql.DriverManager");
                Connection con = (Connection)
                DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
                java.sql.Statement stmt = (java.sql.Statement) con.createStatement();
               
String query="Create table if not exists Moviename(S_no int not null primary key auto_increment ,moviename varchar(20));";


  stmt.executeUpdate(query);
  
            }
            
            catch (Exception e)
            {
                JOptionPane.showMessageDialog (this, e.getMessage());
            }
        
        setLocationRelativeTo(null);
         try
            {
                Class.forName("java.sql.DriverManager");
                Connection con = (Connection)
                DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
                Statement stmt = (Statement) con.createStatement();
               
String query="Create table if not exists date(S_no int not null primary key auto_increment,date varchar(20));";



  stmt.executeUpdate(query);
  
            }
            
            catch (Exception e)
            {
                JOptionPane.showMessageDialog (this, e.getMessage());
            }
        
        setLocationRelativeTo(null);
        try
            {
                Class.forName("java.sql.DriverManager");
                Connection con = (Connection)
                DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
                Statement stmt = (Statement) con.createStatement();
               
String query="Create table if not exists signup(name varchar(20),mobile varchar(100),user_name varchar(20),password varchar(23),s_q_no integer(1),ans varchar(20),mastercard varchar(35),debitcard varchar(35),paypal varchar(35),visa varchar(35)) ;";
    
 stmt.executeUpdate(query);
  
            }
            
            catch (Exception e)
            {
                JOptionPane.showMessageDialog (this, e.getMessage());
            }
        
        setLocationRelativeTo(null);
       
          try
            {
                Class.forName("java.sql.DriverManager");
                Connection con = (Connection)
                DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
                Statement stmt = (Statement) con.createStatement();
               
String query="Create table if not exists latestlogin(sno int not null primary key auto_increment,name varchar(20)) ;";


  stmt.executeUpdate(query);
  
            }
            
            catch (Exception e)
            {
                JOptionPane.showMessageDialog (this, e.getMessage());
            }
          String as="admin";
   String ad="admin1";
   String af="India@123";
   String m="";
          try
{
Class.forName("java.sql.DriverManager");
Connection con = (Connection)
DriverManager.getConnection
("jdbc:mysql://localhost:3306/have_my_seat","root", "1234");
Statement stmt = (Statement) con.createStatement();
String query="SELECT user_name FROM signup WHERE name='"+as+"';";
 
ResultSet rs=stmt.executeQuery(query);

if(rs.next())
{    
   
 m=rs.getString("user_name");

}
else
{
    
  
if (m.equals(ad))
{

}
else
{
    String query1="Insert into signup (name,User_name,password) values('"+as+"','"+ad+"','"+af+"') ;";
     stmt.executeUpdate(query1);

}
}
}
catch (Exception e)
{
JOptionPane.showMessageDialog(this, e.getMessage());
}
    
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login_Window");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setText("User Name");

        jLabel2.setText("Password");

        jPasswordField1.setEchoChar('*');

        jButton2.setText("LOGIN");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("<html><u>Create Account</u></html>");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("<HTML><U>Forgot Password</U></HTML>");
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(27, 27, 27))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2)
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fsd/asasd.PNG"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 431, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(1, 1, 1))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String User_name =jTextField1.getText();
        String pass =new String(jPasswordField1.getPassword());
String user ="admin1";
        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con= (Connection)
            DriverManager.getConnection
            ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
            Statement stmt= (Statement) con.createStatement();
            String query ="select user_name,password from signup where user_name='"+User_name+"'; ";


            ResultSet rs=stmt.executeQuery(query);
            if(rs.next())
            {

                String password1 =rs.getString("password");
                System.out.println(password1);
//String password =rs.getString("user_name");
                if(password1.equals(pass))
                {
                

                    if(User_name.equals(user))
                    {
                        dispose();       
                        new admin1().setVisible(true);  

                    }
                    else
                    {
                        dispose();       
                        new MainGUI().setVisible(true);  

                    }
                }
                else
            {
                JOptionPane.showMessageDialog(this,"sorry ! no such record exist");
            }
            }
            

        }

        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        String name= jTextField1.getText();

        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)
            DriverManager.getConnection("jdbc:mysql://localhost:3306/have_my_seat", "root","1234");
            Statement stmt = (Statement) con.createStatement();

            String query="insert into latestlogin(name) values ('"+name+"') ;";

            stmt.executeUpdate(query);

        }

        catch (Exception e)
        {
            JOptionPane.showMessageDialog (this, e.getMessage());
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
         new signup().setVisible(true);  
dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        String usr=null;
        usr = JOptionPane.showInputDialog(null,"Enter your username:");

        String a = null;
        int que1=0;
        String ans=null;

        String passrt=null;

        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con= (Connection)
            DriverManager.getConnection
            ("jdbc:mysql://localhost:3306/have_my_seat","root","1234");
            Statement stmt= (Statement) con.createStatement();

            String query ="select s_q_no,ans,password from signup where user_name='"+usr+"'; ";

            ResultSet rs=stmt.executeQuery(query);
            if(rs.next())
            {
                que1 = rs.getInt("s_q_no");
                ans = rs.getString("ans");
                passrt = rs.getString("password");

            }

        }

        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        System.out.print(passrt);
        System.out.print(ans);
        System.out.print(que1);

        if(que1==0)
        {
            a="yor best Friend";
        }

        else
        if(que1==0)
        {
            a="your favourite dish";
        }

        else
        if(que1==0)
        {
            a="your favourite colour";
        }

        JPanel panel = new JPanel();
        JLabel label = new JLabel("Enter your answer");
        JPasswordField pass2 = new JPasswordField(10);
        panel.add(label);
        panel.add(pass2);
        String[] options = new String[]{"OK", "Cancel"};
        int option = JOptionPane.showOptionDialog(null, panel, a,
            JOptionPane.NO_OPTION, JOptionPane.QUESTION_MESSAGE,
            null, options, options[1]);
        String passer=new String  (pass2.getPassword());
        System.out.print(passer);

        if(passer.equals(ans))
        {
            JOptionPane.showMessageDialog(null,"your password is"+passrt);
        }
        else
        {
            JOptionPane.showMessageDialog(null,"ans is wrong");
        }
    }//GEN-LAST:event_jLabel8MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login1().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
